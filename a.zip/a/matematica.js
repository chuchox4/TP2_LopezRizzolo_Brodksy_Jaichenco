const PI = 3.14159265359;

const suma = (a, b) => a + b;

const resta = (a, b) => a - b;

function multiplicacion(a, b) {
  return a * b;
}

function division(a, b) {
  return a / b;
} 
export { PI, suma, resta, multiplicacion, division };